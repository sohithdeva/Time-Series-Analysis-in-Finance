library(readxl)
 daily_BPCL <- read_excel("C:/Users/BAASHITH/Desktop/daily_BPCL.xlsx")
 View(daily_BPCL)
 daily_BPCL_modf<-daily_BPCL[c(2:244),]
 View(daily_BPCL_modf)
 ts(daily_BPCL_modf$Returns, frequency = 1)-> daily_BPCL_returns
 daily_BPCL_returns
plot(daily_BPCL_returns)
 plot(diff(daily_BPCL_returns))
 plot(diff(diff(daily_BPCL_returns)))
 plot(diff(diff(daily_BPCL_returns)))
 plot(diff(daily_BPCL_returns))
 acf(diff(diff(daily_BPCL_returns)))
 acf(diff(diff(daily_BPCL_returns)))
 acf(diff(daily_BPCL_returns))
 pacf(diff(daily_BPCL_returns))
 pacf(diff(daily_BPCL_returns), col="red")
 acf(diff(diff(daily_BPCL_returns)))
 acf(diff(diff(daily_BPCL_returns)), col="blue")