library(readxl)
 monthly_BPCL <- read_excel("C:/Users/BAASHITH/Desktop/monthly_BPCL.xlsx")
 View(monthly_BPCL)
 monthly_bpcl_mod-> monthly_BPCL[c(2:60),]
monthly_bpcl_mod<- monthly_BPCL[c(2:60),]
 ts(monthly_bpcl_mod$Returns, frequency = 1)->Monthly_returns_BPCL
 class(Monthly_returns_BPCL)
plot(Monthly_returns_BPCL)
 plot(diff(Monthly_returns_BPCL))
 plot(diff(diff(Monthly_returns_BPCL)))
 acf(diff(diff(Monthly_returns_BPCL)))
 acf(diff(diff(Monthly_returns_BPCL)),col="red")
pacf(diff(diff(Monthly_returns_BPCL)))
 pacf(diff(diff(Monthly_returns_BPCL)),col="blue")