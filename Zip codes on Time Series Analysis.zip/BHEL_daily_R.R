class(R)
R
plot(R)
plot(diff(R))
plot(log(R))
plot(diff(R))
plot(diff(diff(R)))
acf(diff(diff(R)))
daily_BHEL.modf<- daily_BHEL[c(2:244),]
View(daily_BHEL.mod)
acf(diff(diff(R)))
View(daily_BHEL.modf)
ts(daily_BHEL.modf$Returns,frequency = 1)-> Returnss
Returnss
plot(Returnss)
plot(diff(Returnss))
plot(diff(diff(Returnss)))
acf(diff(diff(Returnss)))
plot(diff(diff(Returnss)))
plot(diff(Returnss))
plot(Returnss)
