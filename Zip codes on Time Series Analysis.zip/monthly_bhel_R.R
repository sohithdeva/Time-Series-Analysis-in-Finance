library(readxl)
 monthly_BHEL <- read_excel("C:/Users/BAASHITH/Desktop/monthly_BHEL.xlsx")
 View(monthly_BHEL)
 monthly_BHEL_modf<- monthly_BHEL[c(2:60),]
 View(monthly_BHEL_modf)
 ts(monthly_BHEL_modf$Returns,frequency = 1)->monthly_returns_BHEL
 monthly_returns_BHEL
class(monthly_returns_BHEL)
 plot(monthly_returns_BHEL)
 plot(diff(monthly_returns_BHEL))
 plot(diff(diff(monthly_returns_BHEL)))
 plot(diff(diff(monthly_returns_BHEL)))
 acf(diff(diff(monthly_returns_BHEL)))
 acf(diff(diff(monthly_returns_BHEL)), col="blue")
 pacf(diff(diff(monthly_returns_BHEL)))
 pacf(diff(diff(monthly_returns_BHEL)),col="red")