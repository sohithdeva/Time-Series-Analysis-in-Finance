library(readxl)
 weekly_BPCL <- read_excel("C:/Users/BAASHITH/Desktop/weekly_BPCL.xlsx")
 View(weekly_BPCL)
 weekly_BPCL_modf<- weekly_BPCL[c(2:262),]
 View(weekly_BPCL_modf)
 ts(weekly_BPCL_modf$Returns, frequency = 1)->weekly_BPCL_returns
 weekly_BPCL_returns
class(weekly_BPCL_returns)
  plot(weekly_BPCL_returns)
 plot(diff(weekly_BPCL_returns))
 plot(diff(diff(weekly_BPCL_returns)))
 plot(diff(weekly_BPCL_returns))
 plot(diff(diff(weekly_BPCL_returns)))
 acf(diff(diff(weekly_BPCL_returns)))
 acf(diff(weekly_BPCL_returns))
 pacf(diff(weekly_BPCL_returns))
 pacf(diff(weekly_BPCL_returns),col="red")
 acf(diff(weekly_BPCL_returns),col="blue")
 acf(diff(weekly_BPCL_returns))