Returnss_arima <- arima(Returnss, order = c(2,1,2))
Returnss_arima 
plot(Returnss_arima) 
Returnss_arima_weekly <- arima(weekly_BPCL_returns, order = c(4,0,2))
Returnss_arima_weekly 
plot(Returnss_arima_weekly)
Returnss_arima_weekly <- arima(weekly_BHEL_returns, order = c(3,1,2))
Returnss_arima_weekly 
plot(Returnss_arima_weekly)
Returnss_arima_daily <- arima(daily_BPCL_returns, order = c(2,1,4))
Returnss_arima_daily
plot(Returnss_arima_daily)
Returnss_arima_monthly <- arima(monthly_BPCL_returns, order = c(2,0,2))
Returnss_arima_monthly 
plot(Returnss_arima_monthly)
Returnss_arima_weekly <- arima(weekly_BHEL_returns, order = c(2,2,2))
Returnss_arima_weekly 
plot(Returnss_arima_weekly)
Returnss_arima_daily <- arima(daily_BHEL_returns, order = c(1,0,2))
Returnss_arima_daily
plot(Returnss_arima_daily)
Returnss_arima_monthly <- arima(monthly_BHEL_returns, order = c(3,0,2))
Returnss_arima_monthly 
plot(Returnss_arima_monthly)