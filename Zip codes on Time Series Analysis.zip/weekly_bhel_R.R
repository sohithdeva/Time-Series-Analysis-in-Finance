library(readxl)
 weekly_BHEL <- read_excel("C:/Users/BAASHITH/Desktop/weekly_BHEL.xlsx")
 View(weekly_BHEL)
 weekly_BHEL_modf <- weekly_BHEL[c(2,262),]
 ts(weekly_BHEL_modf$Returns,frequency = 1)-> weekly_returns_BHEL
 weekly_returns_BHEL
View(weekly_BHEL_modf)
 weekly_BHEL_modf <- weekly_BHEL[c(2:262),]
 ts(weekly_BHEL_modf$Returns,frequency = 1)-> weekly_returns_BHEL
weekly_returns_BHEL
class(weekly_returns_BHEL)
 plot(weekly_returns_BHEL)
 plot(diff(weekly_returns_BHEL))
 plot(diff(diff(weekly_returns_BHEL)))
 acf(diff(diff(weekly_returns_BHEL)))
 acf(diff(weekly_returns_BHEL))
 pacf(diff(diff(weekly_returns_BHEL)))
 pacf(diff(weekly_returns_BHEL))
 acf(diff(diff(weekly_returns_BHEL)))
 acf(diff(diff(weekly_returns_BHEL)),col="blue")
 pacf(diff(diff(weekly_returns_BHEL)))
 pacf(diff(diff(weekly_returns_BHEL)),col="red")
adf.test(diff(diff(weekly_returns_BHEL)))